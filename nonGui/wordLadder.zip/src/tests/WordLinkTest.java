package tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class WordLinkTest {

	@Test
	public final void testWordLink() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGeneration() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testTestAllWordLinks() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testShortestPath() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testRemoveDuplicates() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetLetterDiff() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testDiscovery() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testAddWords() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testCheckSrcVsDest() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testRemoveInvalidLength() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testCheckSrcWrd() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testAllWordsLinks() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testTestAdding() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testPrintArray() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testPrintHash() {
		fail("Not yet implemented"); // TODO
	}

}
